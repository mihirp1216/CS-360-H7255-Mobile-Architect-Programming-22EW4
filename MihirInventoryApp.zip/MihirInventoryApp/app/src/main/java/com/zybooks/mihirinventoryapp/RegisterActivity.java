/*
 * Name: Mihir Patel
 * Email: mihir.patel@snhu.edu
 * Class: CS-360-H7255 Mobile Architect & Programming 22EW4
 * 7-2 Project Three
 * April 2022
 */

package com.zybooks.mihirinventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class RegisterActivity extends AppCompatActivity {

    Button RegisterButton, CancelButton;
    EditText NameHolder, PhoneNumberHolder, EmailHolder, PasswordHolder;
    Boolean EmptyHolder;
    SQLiteDatabase db;
    UsersSQLiteHandler handler;
    String F_Result = "Not_Found";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        NameHolder = findViewById(R.id.editTextPersonName);
        PhoneNumberHolder = findViewById(R.id.editTextPhoneNumber);
        EmailHolder = findViewById(R.id.editTextEmailAddress);
        PasswordHolder = findViewById(R.id.editTextPassword);
        RegisterButton = findViewById(R.id.regSignupButton);
        CancelButton = findViewById(R.id.regCancelButton);
        handler = new UsersSQLiteHandler(this);

        // Adding a click listener to the forgotPasswordButton to register it
        RegisterButton.setOnClickListener(view -> {
            String message = CheckEditTextNotEmpty();

            if (!EmptyHolder) {
                // Check to see whether the email is already in the database
                CheckEmailAlreadyExists();
                // After putting data into the database, leave the editText fields empty
                EmptyEditTextAfterDataInsert();
            } else {
                // If any field is empty, display a toast message and focus the field
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        });

        // Adding a click listener to the addCancelButton function
        CancelButton.setOnClickListener(view -> {
            // Returning to LoginActivity after canceling Register
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            this.finish();
        });

    }

    // Add a new user to the database
    public void InsertUserIntoDatabase(){
        String name = NameHolder.getText().toString().trim();
        String phone = PhoneNumberHolder.getText().toString().trim();
        String email = EmailHolder.getText().toString().trim();
        String pass = PasswordHolder.getText().toString().trim();

        User user = new User(name, phone, email, pass);
        handler.createUser(user);

        // After inserting, print the toast message
        Toast.makeText(RegisterActivity.this,"User Registered Successfully", Toast.LENGTH_LONG).show();

        // Returning to LoginActivity after receiving the registration success notification
        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
        this.finish();
    }

    // Checking that the item description is not blank
    public String CheckEditTextNotEmpty() {
        // Obtaining data from fields and saving it in a string variable
        String message = "";
        String name = NameHolder.getText().toString().trim();
        String phone = PhoneNumberHolder.getText().toString().trim();
        String email = EmailHolder.getText().toString().trim();
        String pass = PasswordHolder.getText().toString().trim();

        if (name.isEmpty()) {
            NameHolder.requestFocus();
            EmptyHolder = true;
            message = "User Name is Empty";
        } else if (phone.isEmpty()){
            PhoneNumberHolder.requestFocus();
            EmptyHolder = true;
            message = "User Phone is Empty";
        } else if (email.isEmpty()){
            EmailHolder.requestFocus();
            EmptyHolder = true;
            message = "User Email is Empty";
        } else if (pass.isEmpty()){
            PasswordHolder.requestFocus();
            EmptyHolder = true;
            message = "User Password is Empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

    // Check to see if the user's email address is already in the database
    public void CheckEmailAlreadyExists(){
        String email = EmailHolder.getText().toString().trim();
        db = handler.getWritableDatabase();

        // Adding an email search query to the cursor
        Cursor cursor = db.query(UsersSQLiteHandler.TABLE_NAME, null, " " + UsersSQLiteHandler.COLUMN_3_EMAIL + "=?", new String[]{email}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                // If an email exists, set the value of the result variable to Email Found
                F_Result = "Email Found";
                // Cursor is closing
                cursor.close();
            }
        }
        handler.close();

        // Invoking procedure to validate final result and insert data into SQLite database.
        CheckFinalCredentials();
    }

    // Verify that your login credentials are accurate
    public void CheckFinalCredentials(){
        // Checking to see whether the email is already in the database.
        if(F_Result.equalsIgnoreCase("Email Found"))
        {
            // If an email address is found, a toast message will be displayed.
            Toast.makeText(RegisterActivity.this,"Email Already Exists",Toast.LENGTH_LONG).show();
        }
        else {
            // If the email address does not already exist, the user registration information will be saved in the SQLite database.
            InsertUserIntoDatabase();
        }
        F_Result = "Not_Found" ;
    }

    // After putting data into the database, the edittext will be empty
    public void EmptyEditTextAfterDataInsert(){
        NameHolder.getText().clear();
        PhoneNumberHolder.getText().clear();
        EmailHolder.getText().clear();
        PasswordHolder.getText().clear();
    }

}

