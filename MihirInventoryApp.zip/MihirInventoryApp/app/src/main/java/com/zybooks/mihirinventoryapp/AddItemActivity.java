/*
 * Name: Mihir Patel
 * Email: mihir.patel@snhu.edu
 * Class: CS-360-H7255 Mobile Architect & Programming 22EW4
 * 7-2 Project Three
 * April 2022
 */

package com.zybooks.mihirinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.atomic.AtomicReference;


public class AddItemActivity extends AppCompatActivity {

    String EmailHolder, DescHolder, QtyHolder, UnitHolder;
    TextView UserEmail;
    ImageButton IncreaseQty, DecreaseQty;
    EditText ItemDescValue, ItemQtyValue, ItemUnitValue;
    Button CancelButton, AddItemButton;
    Boolean EmptyHolder;
    ItemsSQLiteHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_additem);

        // Create variables for buttons, textViews, and editText
        UserEmail = findViewById(R.id.textViewLoggedUser);
        ItemDescValue = findViewById(R.id.editTextItemDescription);
        ItemUnitValue = findViewById(R.id.editTextItemUnit);
        IncreaseQty = findViewById(R.id.itemQtyIncrease);
        DecreaseQty = findViewById(R.id.itemQtyDecrease);
        ItemQtyValue = findViewById(R.id.editTextItemQuantity);
        CancelButton = findViewById(R.id.addCancelButton);
        AddItemButton = findViewById(R.id.addItemButton);
        db = new ItemsSQLiteHandler(this);

        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        // Receiving user email send by ItemsListActivity
        EmailHolder = intent.get().getStringExtra(ItemsListActivity.UserEmail);

        // On textViewLoggedUser, set the user's email address
        UserEmail.setText(getString(R.string.logged_user, EmailHolder));

        // itemQtyIncrease forgotPasswordButton now has a click listener
        IncreaseQty.setOnClickListener(view -> {
            int input = 0, total;

            String value = ItemQtyValue.getText().toString().trim();

            if (!value.isEmpty()) {
                input = Integer.parseInt(value);
            }

            total = input + 1;
            ItemQtyValue.setText(String.valueOf(total));
        });

        // itemQtyDecrease forgotPasswordButton now has a click listener
        DecreaseQty.setOnClickListener(view -> {
            int input, total;

            String qty = ItemQtyValue.getText().toString().trim();

            if (qty.equals("0")) {
                Toast.makeText(this, "Item Quantity is Zero", Toast.LENGTH_LONG).show();
            } else {
                input = Integer.parseInt(qty);
                total = input - 1;
                ItemQtyValue.setText(String.valueOf(total));
            }
        });

        // addCancelButton now has a click listener
        CancelButton.setOnClickListener(view -> {
            // Going back to ItemsListActivity after cancel adding item
            Intent add = new Intent();
            setResult(0, add);
            this.finish();
        });

        // Adding a click listener to the addItemButton and sending data to the ItemsListActivity
        AddItemButton.setOnClickListener(view -> InsertItemIntoDatabase());
    }

    // Data is inserted into the database and sent to the ItemsListActivity
    public void InsertItemIntoDatabase() {
        String message = CheckEditTextNotEmpty();

        if (!EmptyHolder) {
            String email = EmailHolder;
            String desc = DescHolder;
            String qty = QtyHolder;
            String unit = UnitHolder;

            Item item = new Item(email, desc, qty, unit);
            db.createItem(item);

            // After inserting into the table, show a toast message
            Toast.makeText(this,"Item Added Successfully", Toast.LENGTH_LONG).show();

            // Close the AddItemActivity window
            Intent add = new Intent();
            setResult(RESULT_OK, add);
            this.finish();
        } else {
            // If the item description is blank, display a toast message and focus the field
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checking item description is not empty
    public String CheckEditTextNotEmpty() {
        // Obtaining field values and putting them in a string variable
        String message = "";
        DescHolder = ItemDescValue.getText().toString().trim();
        UnitHolder = ItemUnitValue.getText().toString().trim();
        QtyHolder = ItemQtyValue.getText().toString().trim();

        if (DescHolder.isEmpty()) {
            ItemDescValue.requestFocus();
            EmptyHolder = true;
            message = "Item Description is Empty";
        } else if (UnitHolder.isEmpty()){
            ItemUnitValue.requestFocus();
            EmptyHolder = true;
            message = "Item Unit is Empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

}

