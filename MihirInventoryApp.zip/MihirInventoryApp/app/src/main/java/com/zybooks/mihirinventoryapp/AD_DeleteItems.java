/*
 * Name: Mihir Patel
 * Email: mihir.patel@snhu.edu
 * Class: CS-360-H7255 Mobile Architect & Programming 22EW4
 * 7-2 Project Three
 * April 2022
 */
package com.zybooks.mihirinventoryapp;

import androidx.appcompat.app.AlertDialog;


public class AD_DeleteItems {

    public static AlertDialog doubleButton(final ItemsListActivity context){
        // For quick dialog creation, use the Builder class
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.ad_delete_title)
                .setIcon(R.drawable.delete_all_items)
                .setCancelable(false)
                .setMessage(R.string.ad_delete_msg)
                .setPositiveButton(R.string.ad_delete_dialog_yes_button, (dialog, arg1) -> {
                    ItemsListActivity.YesDeleteItems();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.ad_delete_dialog_no_button, (dialog, arg1) -> {
                    ItemsListActivity.NoDeleteItems();
                    dialog.cancel();
                });

        // Create and return the AlertDialog object
        return builder.create();
    }
}

