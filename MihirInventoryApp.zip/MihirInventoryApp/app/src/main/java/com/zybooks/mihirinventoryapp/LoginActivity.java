/*
 * Name: Mihir Patel
 * Email: mihir.patel@snhu.edu
 * Class: CS-360-H7255 Mobile Architect & Programming 22EW4
 * 7-2 Project Three
 * April 2022
 */

package com.zybooks.mihirinventoryapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class LoginActivity extends AppCompatActivity {

    Activity activity;
    Button LoginButton, RegisterButton, ForgotPassButton;
    EditText Email, Password;
    String NameHolder, PhoneNumberHolder, EmailHolder, PasswordHolder;
    Boolean EmptyHolder;
    PopupWindow popwindow;
    SQLiteDatabase db;
    UsersSQLiteHandler handler;
    String TempPassword = "NOT_FOUND" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        activity = this;

        LoginButton = findViewById(R.id.signinButton);
        RegisterButton = findViewById(R.id.registerButton);
        ForgotPassButton = findViewById(R.id.forgotPasswordButton);
        Email = findViewById(R.id.editTextEmailAddress);
        Password = findViewById(R.id.editTextPassword);
        handler = new UsersSQLiteHandler(this);

        // Adding a click listener to the forgotPasswordButton to sign in
        LoginButton.setOnClickListener(view -> {
            // Use the Login function
            LoginFunction();
        });

        // Adding a click listener to the forgotPasswordButton to register it.
        RegisterButton.setOnClickListener(view -> {
            // When the forgotPasswordButton is clicked, a new RegisterActivity is launched with the aim of opening a new RegisterActivity.
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        // Adding a click listener to the forgotPasswordButton to register it.
        ForgotPassButton.setOnClickListener(view -> {
            EmailHolder = Email.getText().toString().trim();

            if (!EmailHolder.isEmpty()) {
                forgotPassPopup();
            } else {
                Toast.makeText(LoginActivity.this, "User Email is Empty", Toast.LENGTH_LONG).show();
            }
        });
    }

    // Login functionality
    @SuppressLint("Range")
    public void LoginFunction() {
        String message = CheckEditTextNotEmpty();

        if(!EmptyHolder) {
            // Obtaining write permission for a SQLite database
            db = handler.getWritableDatabase();

            // Adding an email search query to the cursor
            Cursor cursor = db.query(UsersSQLiteHandler.TABLE_NAME, null, " " + UsersSQLiteHandler.COLUMN_3_EMAIL + "=?", new String[]{EmailHolder}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    // Storing the password and name associated with the provided email address.
                    TempPassword = cursor.getString(cursor.getColumnIndex(UsersSQLiteHandler.COLUMN_4_PASSWORD));
                    NameHolder = cursor.getString(cursor.getColumnIndex(UsersSQLiteHandler.COLUMN_1_NAME));
                    PhoneNumberHolder = cursor.getString(cursor.getColumnIndex(UsersSQLiteHandler.COLUMN_2_PHONE_NUMBER));

                    // Cursor is closing
                    cursor.close();
                }
            }
            handler.close();

            // Using the approach to examine the final outcome
            CheckFinalResult();
        } else {
            // If any of the login EditText fields are left blank, this block will be run.
            Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Ensure that the editText fields are not empty.
    public String CheckEditTextNotEmpty() {
        // Obtaining data from fields and saving it in a string variable
        String message = "";
        EmailHolder = Email.getText().toString().trim();
        PasswordHolder = Password.getText().toString().trim();

        if (EmailHolder.isEmpty()){
            Email.requestFocus();
            EmptyHolder = true;
            message = "User Email is Empty";
        } else if (PasswordHolder.isEmpty()){
            Password.requestFocus();
            EmptyHolder = true;
            message = "User Password is Empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

    // Checking the supplied password against the SQLite database's email-associated password
    public void CheckFinalResult(){
        if(TempPassword.equalsIgnoreCase(PasswordHolder)) {
            Toast.makeText(LoginActivity.this,"Login Successful",Toast.LENGTH_SHORT).show();

            // Using intent, send Name to ItemsListActivity
            Bundle bundle = new Bundle();
            bundle.putString("user_name", NameHolder);
            bundle.putString("user_email", EmailHolder);
            bundle.putString("user_phone", PhoneNumberHolder);

            // After receiving the login success message, proceed to ItemsListActivity
            Intent intent = new Intent(LoginActivity.this, ItemsListActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);

            // After a successful login, leave the editText field empty and quit the database.
            EmptyEditTextAfterDataInsert();
        } else {
            // If the credentials are incorrect, an error notice will be displayed
            Toast.makeText(LoginActivity.this,"Incorrect Email or Password\nor User Not Registered",Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND" ;
    }

    // After a successful login, the edittext field is empty
    public void EmptyEditTextAfterDataInsert() {
        Email.getText().clear();
        Password.getText().clear();
    }

    @SuppressLint("Range")
    public void forgotPassPopup() {
        LayoutInflater inflater = activity.getLayoutInflater();
        View layout = inflater.inflate(R.layout.forgot_pass_popup, activity.findViewById(R.id.popup_element));

        popwindow = new PopupWindow(layout, 800, 800, true);
        popwindow.showAtLocation(layout, Gravity.CENTER, 0, 0);

        EditText phone = layout.findViewById(R.id.editTextItemDescriptionPopup);
        TextView password = layout.findViewById(R.id.textViewPassword);

        // Obtaining write permission for a SQLite database.
        db = handler.getWritableDatabase();

        // Adding an email search query to the cursor
        Cursor cursor = db.query(UsersSQLiteHandler.TABLE_NAME, null, " " + UsersSQLiteHandler.COLUMN_3_EMAIL + "=?", new String[]{EmailHolder}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();

                // Storing the password and name associated with the provided email address
                PhoneNumberHolder = cursor.getString(cursor.getColumnIndex(UsersSQLiteHandler.COLUMN_2_PHONE_NUMBER));
                TempPassword = cursor.getString(cursor.getColumnIndex(UsersSQLiteHandler.COLUMN_4_PASSWORD));

                // Cursor is closing
                cursor.close();
            }
        }
        handler.close();

        Button get = layout.findViewById(R.id.forgotGetButton);
        Button cancel = layout.findViewById(R.id.forgotCancelButton);

        get.setOnClickListener(view -> {
            String verifyPhone = phone.getText().toString();

            if(verifyPhone.equals(PhoneNumberHolder)) {
                password.setText(TempPassword);

                new android.os.Handler().postDelayed(() -> popwindow.dismiss(), 2000);
            } else {
                Toast.makeText(activity, "Phone Not Match", Toast.LENGTH_LONG).show();
            }
        });

        cancel.setOnClickListener(view -> {
            Toast.makeText(activity, "Action Canceled", Toast.LENGTH_SHORT).show();
            popwindow.dismiss();
        });
    }
}

